package org.proyecto.primerproyecto.repositories;

import org.proyecto.primerproyecto.models.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {

}
