package org.proyecto.primerproyecto.controllers;


import org.proyecto.primerproyecto.models.Estudiante;

import org.proyecto.primerproyecto.repositories.EstudianteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteRepository estudianteRepository;

    @GetMapping
    public List<Estudiante> getEstudiantes() {
        return this.estudianteRepository.findAll();
    }

    @CrossOrigin
    @GetMapping("/{id}")
    public ResponseEntity<Estudiante> getEstudianteById(@PathVariable Long id) {
        Optional<Estudiante> estudiante = this.estudianteRepository.findById(id);
        /*
        // Este if es lo mismo que el return que no está comentado
        if (estudiante.isPresent()) {
            return ResponseEntity.ok().body(estudiante.get());
        }
        return ResponseEntity.notFound().build();
        */
        return estudiante.map(value -> ResponseEntity.ok().body(value)).orElseGet(() -> ResponseEntity.notFound().build());
    }

}
